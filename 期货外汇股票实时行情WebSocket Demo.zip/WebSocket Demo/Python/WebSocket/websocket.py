import json
import websocket

# 行情对接地址：http://39.107.99.235:1008/market

try:
	import thread
except ImportError:
	import _thread as thread
import time

def on_data(ws, message, msg_type, flag):
	# 解析接收到的数据
	msg = json.loads(message)

	if 'body' not in msg or not msg['body']:
		return

	data = msg['body'];

	StockCode = data['StockCode'];
	Price = data['Price'];
	Open = data['Open'];
	LastClose = data['LastClose'];
	High = data['High'];
	Low = data['Low'];
	Diff = data['Diff'];
	DiffRate = data['DiffRate'];
	BP1 = data['BP1'];
	BV1 = data['BV1'];
	SP1 = data['SP1'];
	SV1 = data['SV1'];
	TotalVol = data['TotalVol'];
	Time = data['Time'];
	LastTime = data['LastTime'];
	BS = data['BS'];
	Depth = data['Depth'];

	#处理业务逻辑.....

	print(StockCode);

def on_error(ws, error):
	print(error)

def on_close(ws):
	print("### closed ###")

def on_open(ws):
	# print("open")
	# 建立连接后订阅品种
	data = {
		'Key': 'btcusdt,ethusdt,fx_sgbpusd'
	}
	ws.send(json.dumps(data))
	# 间隔10秒发送心跳信息
	def run(*args):
		while(True) :
			time.sleep(10)
			ping = {
				'ping' : int(time.time())
			}
			ws.send(json.dumps(ping))
	thread.start_new_thread(run, ())

if __name__ == "__main__":
	# websocket.enableTrace(True)
	ws = websocket.WebSocketApp("ws://39.107.99.235/ws", on_data = on_data, on_error = on_error, on_close = on_close)
	ws.on_open = on_open
	ws.run_forever()

